
georefs/TeamAvitab_2611_2612

NOT TO BE USED FOR REAL WORLD NAVIGATION

Valid from Thu 29 Oct 2026 to Wed 23 Dec 2026

In the Avitab Plugins folder in MapTiles/Mercator/Calibration, remove all previously installed AIRAC cycles for this region
Copy the new "Calibration" folder into MapTiles/Mercator

Some charts are Lambert projection but calibrated as if they are Mercator. There will be some 
inaccuracy in some areas of these charts, but should be OK for flight simulation purposes.

There are some UK AIP charts that contain 2 panels. These may not have calibration or only 1 panel
may be calibrated.
        